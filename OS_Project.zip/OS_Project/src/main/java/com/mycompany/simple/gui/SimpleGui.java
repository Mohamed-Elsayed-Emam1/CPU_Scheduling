/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simple.gui;

/**
 *
 * @author mohamed
 */
public class SimpleGui {

    public static void main(String[] args) {
       CPU_Scheduling OS = new CPU_Scheduling();
        OS.setVisible(true);
        OS.pack();
        OS.setLocationRelativeTo(null); 
    }
}
