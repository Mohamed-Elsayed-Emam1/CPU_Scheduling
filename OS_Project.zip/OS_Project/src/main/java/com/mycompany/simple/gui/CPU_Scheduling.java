package com.mycompany.simple.gui;


import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class CPU_Scheduling extends javax.swing.JFrame {

    
     DefaultTableModel model;
    
    public CPU_Scheduling() {
        initComponents();
        NumberProcess.setText("1");
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        QuantamTimeField = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        NumberProcess = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        CPUTime = new javax.swing.JTextField();
        AddProcess = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        AlgorithmList = new javax.swing.JComboBox<>();
        RunAlgorithm = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 500));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(35, 166, 97));
        jPanel2.setPreferredSize(new java.awt.Dimension(400, 500));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("CPU_Scheduling");

        Table.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.Process", "CPU.T", "Wait.T", "Turn.T"
            }
        ));
        jScrollPane2.setViewportView(Table);

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel6.setText("copyright © Mohamed Elsayed");

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        jLabel7.setText("Quantam.T");

        QuantamTimeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QuantamTimeFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(138, 138, 138)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(QuantamTimeField, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 85, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(QuantamTimeField, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 430, 500);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        jLabel1.setText("No.Process");

        NumberProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberProcessActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        jLabel2.setText("CPU Time");

        CPUTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CPUTimeActionPerformed(evt);
            }
        });

        AddProcess.setBackground(new java.awt.Color(35, 166, 97));
        AddProcess.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        AddProcess.setForeground(new java.awt.Color(51, 51, 51));
        AddProcess.setText("Add Process");
        AddProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddProcessActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(35, 166, 97));
        jLabel3.setText("Algorithm");

        jLabel4.setText("Please Selact Algorithm");

        AlgorithmList.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        AlgorithmList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FCFS", "SJF", "Priority", "Round Robin", " " }));

        RunAlgorithm.setBackground(new java.awt.Color(35, 166, 97));
        RunAlgorithm.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        RunAlgorithm.setText("Run Algorithm");
        RunAlgorithm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RunAlgorithmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4))
                            .addComponent(AlgorithmList, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(RunAlgorithm, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(CPUTime, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(NumberProcess, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(AddProcess, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(NumberProcess, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CPUTime, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(AddProcess, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(AlgorithmList, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(RunAlgorithm, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(430, 0, 360, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumberProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberProcessActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumberProcessActionPerformed

    private void AddProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddProcessActionPerformed
                model = (DefaultTableModel) Table.getModel();
                if(CPUTime.getText().isEmpty() || CPUTime.getText() == "0"){
                   JOptionPane.showMessageDialog(this, "CPU Time UnVailed","Error",JOptionPane.ERROR_MESSAGE);
                }else{
        //add
                Add_NoProcess_To_Table();
        //clear CPU 
                ClearCPUTime();
        //incerment noProcess
                incrementNumberProcess();
                }    
                
    }//GEN-LAST:event_AddProcessActionPerformed

    private void RunAlgorithmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RunAlgorithmActionPerformed
        int rowCount = model.getRowCount();
        
        int Cputime [] = new int [rowCount];
        
        int WaitingTime [] = new int [rowCount] ;
        int TurnaroundTime [] = new int [rowCount];
        
        
       if(AlgorithmList.getSelectedItem().equals("FCFS")){
                   for(int i=0 ; i < rowCount ; i++){
                Cputime[i] = Integer.parseInt(model.getValueAt(i, 1).toString());
        }
        
        WaitingTime [0] = 0;
        for(int i=1 ; i < rowCount ; i++){
            WaitingTime [i] = WaitingTime[i-1] + Cputime[i-1];
            
            
        }
        for(int i=0 ; i < rowCount ; i++){
            TurnaroundTime [i] = WaitingTime[i] + Cputime[i];
            
        }    
        
        SetWaitingAndTurnAroundTime(WaitingTime,TurnaroundTime);
        ShowMessageAverageWT("FCFS");
    }   
       else if (AlgorithmList.getSelectedItem().equals("SJF")){
                   List<Object[]> TableData = new ArrayList<>();
        
        for(int i=0; i<rowCount; i++){
            Object[] row = new Object[4];
            row[0] = model.getValueAt(i, 0);
            row[1] = Integer.parseInt( model.getValueAt(i, 1).toString());
            row[2] = 0;//waiting Time
            row[3] = 0; //turnAround Time ;
            TableData.add(row);
       
        }  
        
     TableData.sort((a,b) -> Integer.compare((int) a[1], (int)b[1]));
    
  int CurrentTime = 0;
    for(int i=0 ; i<rowCount; i++){
        Object[] row = TableData.get(i);
       int CpuTime = (int) row [1];
       row[2] = CurrentTime;
       row[3] = (int)row[2] + CpuTime;
       CurrentTime += CpuTime;
       
    }
    

    SeaderTableData(TableData);
        ShowMessageAverageWT("SJF");
       }
       else if (AlgorithmList.getSelectedItem().equals("Priority")){
    model.addColumn("Priority.P") ;
        
        for(int i=0 ; i< rowCount ; i++){
          String InputPriority =  JOptionPane.showInputDialog(this , "Enter Number Of Priority process" +(i+1)+":","Input Priority Process", JOptionPane.QUESTION_MESSAGE);
          model.setValueAt(InputPriority, i, 4);
          
        }
    
        List<Object[]> TableData = new ArrayList<>();
        
        for (int i=0 ; i< rowCount ; i++){
            Object[] Process = new Object[5];
            Process[0] = model.getValueAt(i, 0);
            Process[1] = Integer.parseInt(model.getValueAt(i, 1).toString());
            Process[2] = 0;
            Process[3] = 0;
            Process[4] = Integer.parseInt(model.getValueAt(i, 4).toString()) ;
            TableData.add(Process);
            
        }
        
        TableData.sort((a,b) -> Integer.compare((int) a[4], (int) b[4]));
        
        
        
        int currentTime = 0 ;
        for (int i=0 ; i < rowCount ; i++){
            
            Object[] Process = TableData.get(i);
            int CPUTime = (int) Process[1];
            Process[2] = currentTime;
            Process[3] = (int) Process[2] + CPUTime;
            
            currentTime += CPUTime;
            
        }
         SeaderTableData(TableData);
         ShowMessageAverageWT("Priority Algorithm");
        
        
        
        
       }
       else if (AlgorithmList.getSelectedItem().equals("Round Robin")){

       String inputQuantam = JOptionPane.showInputDialog(this, 
               "Enter Quantam time for all process", 
               "Quantam Time",
               JOptionPane.QUESTION_MESSAGE);
       QuantamTimeField.setText(inputQuantam);
       int QuantamTime = Integer.parseInt(inputQuantam);
       List<Object[]> tableData = new ArrayList<>();
       int [] backupCpuTime = new int [rowCount];
       
       for(int i=0; i<rowCount; i++){
       Object[] process = new Object[4];
       
       process[0] = model.getValueAt(i, 0);
       process[1] = Integer.parseInt(model.getValueAt(i, 1).toString());
       backupCpuTime[i] = Integer.parseInt(model.getValueAt(i, 1).toString());
       process[2] = 0; 
       process[3] = 0;
       
       tableData.add(process);
       
       }
       
       //////
       
       boolean allProcessesIscomplete;
       int currentTime = 0;
       do{
           allProcessesIscomplete = true;
           for(Object[] process : tableData){
               int CPUTime = (int) process[1];
               
               if(CPUTime > 0){
                   allProcessesIscomplete = false;
                   if(CPUTime > QuantamTime){
                   currentTime += QuantamTime;
                   process[1] = (int) process[1] - QuantamTime;
                   
                }
                   else {
                   
                   currentTime += CPUTime;
                   process[1] = 0;
                   process[3] = currentTime;
                   process[2] = (int) process[3] - CPUTime;
                   }  
               }
           }
       }while (!allProcessesIscomplete);
       for(int i=0; i < rowCount; i++){
           Object[] process = tableData.get(i);
       model.setValueAt(process[0], i, 0);
       model.setValueAt(backupCpuTime[i], i, 1);
       model.setValueAt(process[2], i, 2);
       model.setValueAt(process[3], i, 3);
       }
                 ShowMessageAverageWT("Round Robin");

     }
    
    }//GEN-LAST:event_RunAlgorithmActionPerformed
    
    
    private void CPUTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CPUTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CPUTimeActionPerformed

    private void QuantamTimeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QuantamTimeFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_QuantamTimeFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CPU_Scheduling.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CPU_Scheduling.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CPU_Scheduling.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CPU_Scheduling.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CPU_Scheduling().setVisible(true);
            }
        });
        
    }
    
    private void SeaderTableData(List<Object[]> TableData){
        for (int i=0 ; i< TableData.size() ; i++) {
            Object[] row = TableData.get(i);
            model.setValueAt(row[0], i, 0);
            model.setValueAt(row[1], i, 1);
            model.setValueAt(row[2], i, 2);
            model.setValueAt(row[3], i, 3);
            if(model.getColumnCount() == 5){
                model.setValueAt(row[4] ,i, 4);
            }
        }
    }
    
    private void Add_NoProcess_To_Table () {
        model.addRow(new Object[]{"p"+NumberProcess.getText(), CPUTime.getText(),0,0});
    }
    
    private void ClearCPUTime () {
        CPUTime.setText("");
    } 
    
    private void incrementNumberProcess(){
        int Number  = Integer.parseInt(NumberProcess.getText());
        Number ++;
        NumberProcess.setText(Number+"");
    }
           
    private void SetWaitingAndTurnAroundTime(int WaitingTime[] , int TurnAroundTime[]){
        for(int i=0; i<model.getRowCount();i++){
            model.setValueAt(WaitingTime[i], i, 2);
            model.setValueAt(TurnAroundTime[i], i, 3);
        }
        
    }
    
    private void ShowMessageAverageWT(String Algorithm){
        double totalwaiting=0;
        double totalTurnaround=0;
        for(int i=0 ;i<model.getRowCount() ; i++){
            totalwaiting += Integer.parseInt(model.getValueAt(i, 2).toString());
            totalTurnaround += Integer.parseInt(model.getValueAt(i, 3).toString());
            
        }
       totalwaiting /= model.getRowCount();
       totalTurnaround /= model.getRowCount();
       JOptionPane.showMessageDialog( this, "in "+Algorithm+" ] \n Average Waiting Time :"+totalwaiting+ "\n Average TurnAround Time  :"+totalTurnaround,"Result" , JOptionPane.INFORMATION_MESSAGE );
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddProcess;
    private javax.swing.JComboBox<String> AlgorithmList;
    private javax.swing.JTextField CPUTime;
    private javax.swing.JTextField NumberProcess;
    private javax.swing.JTextField QuantamTimeField;
    private javax.swing.JButton RunAlgorithm;
    private javax.swing.JTable Table;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
